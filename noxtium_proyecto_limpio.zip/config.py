import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        "sqlite:///noxtium.db",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    META_APP_ID = os.getenv("META_APP_ID", "")
    META_APP_SECRET = os.getenv("META_APP_SECRET", "")
    META_GRAPH_VERSION = os.getenv("META_GRAPH_VERSION", "v25.0")
    META_EMBEDDED_SIGNUP_CONFIG_ID = os.getenv("META_EMBEDDED_SIGNUP_CONFIG_ID", "")
    META_WEBHOOK_VERIFY_TOKEN = os.getenv("META_WEBHOOK_VERIFY_TOKEN", "")

    META_TEST_PHONE_NUMBER_ID = os.getenv("META_TEST_PHONE_NUMBER_ID", "")
    META_TEST_WABA_ID = os.getenv("META_TEST_WABA_ID", "")

    N8N_WEBHOOK_URL = os.getenv("N8N_WEBHOOK_URL", "")
    N8N_WEBHOOK_SECRET = os.getenv("N8N_WEBHOOK_SECRET", "")
    FERNET_KEY = os.getenv("FERNET_KEY", "")
    DEMO_COMPANY_ID = os.getenv("DEMO_COMPANY_ID", "")
    DEVELOPMENT_PAYMENT_DEMO = os.getenv("DEVELOPMENT_PAYMENT_DEMO", "true").lower() == "true"
