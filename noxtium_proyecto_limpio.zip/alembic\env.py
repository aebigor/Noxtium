from logging.config import fileConfig
import os
from alembic import context
from sqlalchemy import engine_from_config, pool
from config import Config
from app.database import db
from app import models  # noqa: F401

config = context.config
if config.config_file_name is not None:
    if config.config_file_name:
        try:
            fileConfig(config.config_file_name)
        except (KeyError, ValueError):
            pass

database_url = os.getenv("DATABASE_URL") or Config.SQLALCHEMY_DATABASE_URI
config.set_main_option("sqlalchemy.url", database_url.replace("%", "%%"))
target_metadata = db.metadata

def run_migrations_offline():
    context.configure(
        url=config.get_main_option("sqlalchemy.url"),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()

def run_migrations_online():
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
