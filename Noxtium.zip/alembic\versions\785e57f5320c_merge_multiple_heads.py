"""merge multiple heads

Revision ID: 785e57f5320c
Revises: 0003_manual_payments, 0003_roles_receipts_consultations
Create Date: 2026-10-13 15:11:05.840725
"""

from alembic import op
import sqlalchemy as sa


revision = '785e57f5320c'
down_revision = ('0003_manual_payments', '0003_roles_receipts_consultations')
branch_labels = None
depends_on = None

def upgrade() -> None:
    pass

def downgrade() -> None:
    pass
