"""roles, manual receipts and module integration consultations"""
from alembic import op
import sqlalchemy as sa

revision = "0003_roles_receipts_consultations"
down_revision = "0002_billing_portal"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("users", sa.Column("role", sa.String(length=20), nullable=False, server_default="client"))
    op.create_index("ix_users_role", "users", ["role"])
    op.add_column("payments", sa.Column("receipt_filename", sa.String(length=255), nullable=True))
    op.create_table(
        "consultation_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("contact_method", sa.String(length=20), nullable=False),
        sa.Column("contact_value", sa.String(length=255), nullable=False),
        sa.Column("preferred_date", sa.String(length=40)),
        sa.Column("preferred_time", sa.String(length=40)),
        sa.Column("modules", sa.JSON(), nullable=False),
        sa.Column("business_description", sa.Text()),
        sa.Column("status", sa.String(length=30), nullable=False, server_default="PENDING"),
        sa.Column("admin_notes", sa.Text()),
        sa.Column("meeting_url", sa.String(length=1000)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["company_id"], ["companies.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
    )
    op.create_index("ix_consultation_requests_company_id", "consultation_requests", ["company_id"])
    op.create_index("ix_consultation_requests_user_id", "consultation_requests", ["user_id"])
    op.create_index("ix_consultation_requests_status", "consultation_requests", ["status"])


def downgrade():
    op.drop_table("consultation_requests")
    op.drop_column("payments", "receipt_filename")
    op.drop_index("ix_users_role", table_name="users")
    op.drop_column("users", "role")
