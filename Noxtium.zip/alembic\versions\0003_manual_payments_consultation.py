"""add company manual payment fields and free consultation requests"""
from alembic import op
import sqlalchemy as sa

revision = "0003_manual_payments"
down_revision = "0002_billing_portal"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("companies", sa.Column("plan", sa.String(120), nullable=True))
    op.add_column("companies", sa.Column("payment_status", sa.String(20), nullable=False, server_default="pending"))
    op.add_column("companies", sa.Column("receipt_filename", sa.String(255), nullable=True))
    op.add_column("companies", sa.Column("legal_name", sa.String(200), nullable=True))
    op.add_column("companies", sa.Column("document_type", sa.String(30), nullable=True))
    op.add_column("companies", sa.Column("document_number", sa.String(60), nullable=True))
    op.add_column("companies", sa.Column("address", sa.String(255), nullable=True))
    # Existing customers are not unexpectedly locked by this migration.
    op.execute("UPDATE companies SET payment_status = CASE WHEN is_active THEN 'active' ELSE 'pending' END")
    op.create_table(
        "consultation_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id", ondelete="CASCADE"), nullable=False),
        sa.Column("contact_name", sa.String(150), nullable=False),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("phone", sa.String(50), nullable=False),
        sa.Column("business_type", sa.String(120), nullable=False),
        sa.Column("modules", sa.JSON(), nullable=False),
        sa.Column("details", sa.Text()),
        sa.Column("status", sa.String(30), nullable=False, server_default="new"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_consultation_requests_company_id", "consultation_requests", ["company_id"])
    op.create_index("ix_consultation_requests_status", "consultation_requests", ["status"])


def downgrade():
    op.drop_table("consultation_requests")
    for col in ("address", "document_number", "document_type", "legal_name", "receipt_filename", "payment_status", "plan"):
        op.drop_column("companies", col)
